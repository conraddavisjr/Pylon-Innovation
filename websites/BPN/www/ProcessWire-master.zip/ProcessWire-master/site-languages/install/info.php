<?php if(!defined("PROCESSWIRE_INSTALL")) die();
$info = array(
	'title' => "Multi-Language", 
	'summary' => 
		"A multi-language version of the default site profile. Front-end and back-end in English, German and Finnish, and you can " . 
		"of course change them or add more. Uses the same template development strategies as the default intermediate profile.", 
	'screenshot' => "languages-screenshot.png"
	);
