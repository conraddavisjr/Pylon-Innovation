<?php 

/**
 * Home template
 *
 */

include("./head.inc"); 

echo $page->body;

include("./foot.inc"); 

