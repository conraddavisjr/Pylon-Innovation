# Admin Theme Reno

An alternate core admin theme for ProcessWire CMS.
This theme is included as part of the ProcessWire as of version 2.5.
Please visit modules > site > admin in your installation to install.